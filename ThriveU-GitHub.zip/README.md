# ThriveU - GitHub Pages upload

Upload the CONTENTS of this folder to a GitHub repository.

1. Create a public repository, for example `ThriveU-CS1102`.
2. Upload these files at the repository root:
   - index.html
   - Draft10.html
   - Questionnaire1.html
   - interactive.html
   - Empathy-Wall7.html
   - Profile.html
   - conclusion.html
   - pages.html
   - thriveu-shared.css
   - photos/site/
   - interactive-assets/
3. GitHub -> Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. The site will be at https://<your-username>.github.io/ThriveU-CS1102/

The PDF in this folder uses relative links. When the PDF is opened from GitHub
Pages, its links open the same repository pages, so no URL editing is needed.
