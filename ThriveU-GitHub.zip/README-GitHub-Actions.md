# ThriveU GitHub Pages

Public site: https://eleanor4210.github.io/ThriveU-project/

1. Upload `ThriveU-GitHub.zip` to the repository root.
2. Create `.github/workflows/pages.yml` with the included workflow.
3. Settings -> Pages -> Source: GitHub Actions.
4. Actions -> Deploy ThriveU to GitHub Pages -> Re-run all jobs if needed.

The report PDF is submitted separately. The site ZIP includes report-assets/ so the PDF high-resolution image links work after deployment.
